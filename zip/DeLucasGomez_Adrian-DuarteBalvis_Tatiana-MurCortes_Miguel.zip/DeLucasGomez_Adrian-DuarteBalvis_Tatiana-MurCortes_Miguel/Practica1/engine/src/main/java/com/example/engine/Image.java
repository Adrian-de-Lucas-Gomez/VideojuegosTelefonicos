package com.example.engine;

public interface Image {

    int getWidth();
    int getHeight();
}

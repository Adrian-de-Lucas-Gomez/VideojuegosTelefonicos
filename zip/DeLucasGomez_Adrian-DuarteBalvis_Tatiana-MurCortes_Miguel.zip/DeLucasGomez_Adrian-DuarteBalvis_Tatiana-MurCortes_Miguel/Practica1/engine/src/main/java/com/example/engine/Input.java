package com.example.engine;

import java.util.ArrayList;

public interface Input {
    ArrayList<TouchEvent> getTouchEvents();
}
